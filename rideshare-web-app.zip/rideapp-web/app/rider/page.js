"use client";
import { useState, useEffect, useRef } from "react";
import {
  MapPin, Navigation, Search, User, Car, Clock, ChevronLeft, Check, Shield, Mic, X, MessageCircle, Star,
} from "lucide-react";
import CityMap from "../../components/CityMap";
import ChatPanel from "../../components/ChatPanel";
import { ACCENT, AMBER } from "../../lib/tokens";
import { fareFor, seededTrip } from "../../lib/fare";
import {
  signUpRider, loginRider, signOut, updateRiderProfile, rateDriver,
  createRide, subscribeToRide,
} from "../../lib/db";

const HOME = { x: 20, y: 78 };
const DEST = { x: 82, y: 22 };
const DRIVER_START = { x: 8, y: 30 };
const QUICK_REPLIES_RIDER = ["I'm outside", "On my way down", "Running 2 min late", "Thank you!"];

function lerp(a, b, t) { return a + (b - a) * t; }
function pointAt(path, t) {
  const segCount = path.length - 1;
  const scaled = t * segCount;
  const i = Math.min(Math.floor(scaled), segCount - 1);
  const localT = scaled - i;
  const a = path[i], b = path[i + 1];
  return { x: lerp(a.x, b.x, localT), y: lerp(a.y, b.y, localT) };
}

// ---------- Auth ----------
function AuthScreen({ onAuthed }) {
  const [mode, setMode] = useState("login");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  const submit = async (e) => {
    e.preventDefault();
    setError("");
    if (!email || !password || (mode === "signup" && !name)) { setError("Fill in every field to continue."); return; }
    setBusy(true);
    try {
      const user = mode === "signup"
        ? await signUpRider({ name, email: email.trim().toLowerCase(), password })
        : await loginRider({ email: email.trim().toLowerCase(), password });
      onAuthed(user);
    } catch (err) {
      setError(err.message?.replace("Firebase: ", "") || "Something went wrong.");
    }
    setBusy(false);
  };

  return (
    <div className="min-h-full w-full flex flex-col justify-center px-8" style={{ background: "#111318" }}>
      <div className="mb-10">
        <div className="w-11 h-11 rounded-2xl mb-6 flex items-center justify-center" style={{ background: ACCENT }}>
          <Navigation size={22} color="#111318" strokeWidth={2.5} />
        </div>
        <h1 className="text-3xl font-semibold tracking-tight" style={{ color: "#F5F5F0" }}>
          {mode === "login" ? "Welcome back" : "Let's get you a ride"}
        </h1>
        <p className="mt-1 text-sm" style={{ color: "#7A7F8A" }}>
          {mode === "login" ? "Log in to keep moving." : "Set up your account in seconds."}
        </p>
      </div>

      <form onSubmit={submit} className="space-y-3">
        {mode === "signup" && (
          <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Full name"
            className="w-full px-4 py-3.5 rounded-xl text-base outline-none"
            style={{ background: "#1D2028", color: "#F5F5F0", border: "1px solid #2B2F3A" }} />
        )}
        <input value={email} onChange={(e) => setEmail(e.target.value)} placeholder="Email" type="email"
          className="w-full px-4 py-3.5 rounded-xl text-base outline-none"
          style={{ background: "#1D2028", color: "#F5F5F0", border: "1px solid #2B2F3A" }} />
        <input value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Password" type="password"
          className="w-full px-4 py-3.5 rounded-xl text-base outline-none"
          style={{ background: "#1D2028", color: "#F5F5F0", border: "1px solid #2B2F3A" }} />

        {error && <p className="text-sm" style={{ color: "#FF6B6B" }}>{error}</p>}

        <button type="submit" disabled={busy}
          className="w-full py-3.5 rounded-xl font-medium text-base mt-2 transition active:scale-[0.98]"
          style={{ background: ACCENT, color: "#111318" }}>
          {busy ? "One sec…" : mode === "login" ? "Log in" : "Create account"}
        </button>
      </form>

      <button onClick={() => { setMode(mode === "login" ? "signup" : "login"); setError(""); }}
        className="mt-6 text-sm text-center" style={{ color: "#7A7F8A" }}>
        {mode === "login" ? (<>New here? <span style={{ color: "#F5F5F0" }}>Create an account</span></>)
          : (<>Already have an account? <span style={{ color: "#F5F5F0" }}>Log in</span></>)}
      </button>
    </div>
  );
}

// ---------- Safety Toolkit ----------
function SafetyToolkitScreen({ user, onBack, onUpdateUser }) {
  const [enabled, setEnabled] = useState(!!user.audioRecordingEnabled);
  const toggle = async () => {
    const next = !enabled;
    setEnabled(next);
    await updateRiderProfile(user.uid, { audioRecordingEnabled: next });
    onUpdateUser({ ...user, audioRecordingEnabled: next });
  };
  return (
    <div className="w-full h-full flex flex-col" style={{ background: "#F5F5F0" }}>
      <div className="flex items-center gap-3 p-4 pt-6">
        <button onClick={onBack} className="w-9 h-9 rounded-full flex items-center justify-center" style={{ background: "#EDEBE2" }}>
          <ChevronLeft size={18} color="#111318" />
        </button>
        <h2 className="text-base font-semibold" style={{ color: "#111318" }}>Safety Toolkit</h2>
      </div>
      <div className="px-4 mt-4">
        <div className="rounded-2xl p-4" style={{ background: "#fff", border: "1px solid #E4E2D9" }}>
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full flex items-center justify-center" style={{ background: `${ACCENT}22` }}>
              <Mic size={18} color={ACCENT} />
            </div>
            <div className="flex-1">
              <p className="text-sm font-semibold" style={{ color: "#111318" }}>Audio recording</p>
              <p className="text-xs mt-0.5" style={{ color: "#7A7F8A" }}>Record trip audio on your device for safety</p>
            </div>
            <button onClick={toggle}
              className="w-12 h-7 rounded-full flex items-center px-0.5 transition"
              style={{ background: enabled ? ACCENT : "#D8D6CE", justifyContent: enabled ? "flex-end" : "flex-start" }}>
              <span className="w-6 h-6 rounded-full bg-white block" />
            </button>
          </div>
        </div>
        <div className="mt-4 space-y-3 text-xs" style={{ color: "#7A7F8A" }}>
          <p>When on, your trips are recorded on your own device — not on a server, not visible to your driver or anyone else.</p>
          <p>Recordings stay locked. Only you can choose to submit one if you report a safety issue.</p>
          <p>Your driver will see a notice that recording may be on for a trip. In some states, both sides must be notified before recording.</p>
        </div>
      </div>
    </div>
  );
}

// ---------- Home ----------
function HomeScreen({ user, onRequest, onLogout, onSafety }) {
  return (
    <div className="relative w-full h-full">
      <div className="absolute inset-0"><CityMap driverPos={null} showRoute={false} /></div>
      <div className="absolute top-0 left-0 right-0 p-4 flex items-center justify-between">
        <button onClick={onLogout} className="w-10 h-10 rounded-full flex items-center justify-center"
          style={{ background: "rgba(17,19,24,0.85)", border: "1px solid #2B2F3A" }}>
          <User size={18} color="#F5F5F0" />
        </button>
        <div className="px-3 py-1.5 rounded-full text-xs"
          style={{ background: "rgba(17,19,24,0.85)", color: "#7A7F8A", border: "1px solid #2B2F3A" }}>
          Hi, {user.name.split(" ")[0]}
        </div>
        <button onClick={onSafety} className="w-10 h-10 rounded-full flex items-center justify-center"
          style={{ background: "rgba(17,19,24,0.85)", border: "1px solid #2B2F3A" }}>
          <Shield size={17} color={user.audioRecordingEnabled ? AMBER : "#F5F5F0"} />
        </button>
      </div>
      <div className="absolute bottom-0 left-0 right-0 rounded-t-3xl p-5 pb-8" style={{ background: "#F5F5F0" }}>
        <div className="w-9 h-1 rounded-full mx-auto mb-5" style={{ background: "#D8D6CE" }} />
        <h2 className="text-lg font-semibold mb-3" style={{ color: "#111318" }}>Where to?</h2>
        <button onClick={onRequest} className="w-full flex items-center gap-3 px-4 py-3.5 rounded-xl active:scale-[0.98] transition"
          style={{ background: "#111318" }}>
          <Search size={17} color="#7A7F8A" />
          <span className="text-sm" style={{ color: "#9CA0AA" }}>Enter destination</span>
        </button>
        <div className="mt-5">
          <p className="text-xs uppercase tracking-wide mb-2" style={{ color: "#9A9890" }}>Suggestions</p>
          {["Downtown Office", "The Studio", "Riverside Market"].map((place) => (
            <button key={place} onClick={onRequest} className="w-full flex items-center gap-3 py-2.5 border-b last:border-b-0" style={{ borderColor: "#E4E2D9" }}>
              <MapPin size={16} color={ACCENT} />
              <span className="text-sm" style={{ color: "#111318" }}>{place}</span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

// ---------- Destination entry ----------
function DestinationScreen({ onBack, onConfirm }) {
  const [dest, setDest] = useState("");
  return (
    <div className="w-full h-full flex flex-col" style={{ background: "#F5F5F0" }}>
      <div className="flex items-center gap-3 p-4 pt-6">
        <button onClick={onBack} className="w-9 h-9 rounded-full flex items-center justify-center" style={{ background: "#EDEBE2" }}>
          <ChevronLeft size={18} color="#111318" />
        </button>
        <h2 className="text-base font-semibold" style={{ color: "#111318" }}>Set destination</h2>
      </div>
      <div className="px-4 mt-2 space-y-3">
        <div className="flex items-center gap-3 px-4 py-3 rounded-xl" style={{ background: "#EDEBE2" }}>
          <div className="w-2 h-2 rounded-full" style={{ background: ACCENT }} />
          <span className="text-sm" style={{ color: "#111318" }}>Current location</span>
        </div>
        <div className="flex items-center gap-3 px-4 py-3 rounded-xl" style={{ background: "#fff", border: `1.5px solid ${ACCENT}` }}>
          <div className="w-2 h-2 rounded-sm" style={{ background: AMBER }} />
          <input autoFocus value={dest} onChange={(e) => setDest(e.target.value)} placeholder="Where are you headed?"
            className="text-sm outline-none w-full bg-transparent" style={{ color: "#111318" }} />
        </div>
        {dest.trim() && (
          <div className="rounded-xl p-4 flex items-center justify-between" style={{ background: "#EDEBE2" }}>
            <div>
              <p className="text-sm font-semibold" style={{ color: "#111318" }}>Estimated fare</p>
              <p className="text-xs mt-0.5" style={{ color: "#7A7F8A" }}>
                {seededTrip(dest.trim()).miles} mi · ~{seededTrip(dest.trim()).minutes} min
              </p>
            </div>
            <p className="text-xl font-semibold" style={{ color: ACCENT }}>${fareFor(dest.trim()).fare.toFixed(2)}</p>
          </div>
        )}
      </div>
      <div className="mt-auto p-4">
        <button disabled={!dest.trim()} onClick={() => onConfirm(dest.trim())}
          className="w-full py-3.5 rounded-xl font-medium text-base disabled:opacity-40" style={{ background: ACCENT, color: "#111318" }}>
          {dest.trim() ? `Confirm • $${fareFor(dest.trim()).fare.toFixed(2)}` : "Confirm destination"}
        </button>
      </div>
    </div>
  );
}

// ---------- Finding driver ----------
function FindingDriverScreen({ rideId, destination, onAccepted }) {
  useEffect(() => {
    const unsub = subscribeToRide(rideId, (ride) => {
      if (ride.status === "accepted") onAccepted(ride);
    });
    return unsub;
  }, [rideId]);

  return (
    <div className="w-full h-full relative">
      <CityMap driverPos={DRIVER_START} showRoute={false} />
      <div className="absolute inset-0 flex flex-col items-center justify-center px-8">
        <div className="relative w-16 h-16 mb-6">
          <div className="absolute inset-0 rounded-full animate-ping" style={{ background: ACCENT, opacity: 0.3 }} />
          <div className="absolute inset-0 rounded-full flex items-center justify-center" style={{ background: ACCENT }}>
            <Car size={26} color="#111318" />
          </div>
        </div>
        <p className="text-base font-medium" style={{ color: "#F5F5F0" }}>Finding you a driver…</p>
        <p className="text-sm mt-1" style={{ color: "#7A7F8A" }}>Headed to {destination}</p>
      </div>
    </div>
  );
}

// ---------- Tracking ----------
function TrackingScreen({ rideId, destination, onComplete }) {
  const [ride, setRide] = useState(null);
  const [t, setT] = useState(0);
  const [chatOpen, setChatOpen] = useState(false);
  const [seenMsgCount, setSeenMsgCount] = useState(0);
  const rafRef = useRef();
  const startRef = useRef(null);
  const lastStatusRef = useRef(null);

  const pickupPath = [DRIVER_START, { x: DRIVER_START.x, y: 78 }, HOME];
  const tripPath = [HOME, { x: HOME.x, y: 45 }, { x: DEST.x, y: 45 }, DEST];

  useEffect(() => {
    const unsub = subscribeToRide(rideId, (r) => {
      setRide(r);
      if (r.status === "completed") onComplete(r);
    });
    return unsub;
  }, [rideId]);

  const status = ride?.status || "accepted";
  const phase = status === "accepted" ? "toPickup" : status === "arrived_pickup" ? "waitingPickup" : "toDest";

  useEffect(() => {
    if (lastStatusRef.current === phase) return;
    lastStatusRef.current = phase;
    setT(0);
    startRef.current = null;
  }, [phase]);

  useEffect(() => {
    if (phase === "waitingPickup") return;
    const duration = phase === "toPickup" ? 5000 : 6000;
    const step = (ts) => {
      if (!startRef.current) startRef.current = ts;
      const progress = Math.min((ts - startRef.current) / duration, 1);
      setT(progress);
      if (progress < 1) rafRef.current = requestAnimationFrame(step);
    };
    rafRef.current = requestAnimationFrame(step);
    return () => cancelAnimationFrame(rafRef.current);
  }, [phase]);

  const driverPos = phase === "waitingPickup" ? HOME : pointAt(phase === "toDest" ? tripPath : pickupPath, t);
  const statusText = {
    toPickup: "Driver is on the way",
    waitingPickup: "Driver has arrived — hop in",
    toDest: `Heading to ${destination}`,
  }[phase];

  const driverName = ride?.driverName || "Your driver";
  const carModel = ride?.carModel || "";
  const plate = ride?.plate || "";

  return (
    <div className="w-full h-full relative">
      <CityMap driverPos={driverPos} showRoute={phase !== "toPickup"} />
      <div className="absolute top-4 left-4 right-4">
        {ride?.driverRecording && (
          <div className="px-4 py-2.5 rounded-xl flex items-center gap-2 mb-2" style={{ background: "rgba(108,92,231,0.15)", border: `1px solid ${ACCENT}` }}>
            <Shield size={14} color={ACCENT} />
            <span className="text-xs" style={{ color: "#F5F5F0" }}>This trip may be audio recorded for safety</span>
          </div>
        )}
        <div className="px-4 py-2.5 rounded-full flex items-center gap-2" style={{ background: "rgba(17,19,24,0.85)", border: "1px solid #2B2F3A" }}>
          <div className="w-2 h-2 rounded-full" style={{ background: AMBER }} />
          <span className="text-sm" style={{ color: "#F5F5F0" }}>{statusText}</span>
        </div>
      </div>
      <div className="absolute bottom-0 left-0 right-0 rounded-t-3xl p-5 pb-8" style={{ background: "#F5F5F0" }}>
        <div className="w-9 h-1 rounded-full mx-auto mb-5" style={{ background: "#D8D6CE" }} />
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-full flex items-center justify-center" style={{ background: ACCENT }}>
            <Car size={20} color="#111318" />
          </div>
          <div className="flex-1">
            <p className="font-semibold text-sm" style={{ color: "#111318" }}>{driverName}</p>
            <p className="text-xs" style={{ color: "#7A7F8A" }}>{carModel}{plate ? ` · ${plate}` : ""}</p>
          </div>
          <button onClick={() => { setChatOpen(true); setSeenMsgCount((ride?.messages || []).length); }}
            className="relative w-11 h-11 rounded-full flex items-center justify-center" style={{ background: "#EDEBE2" }}>
            <MessageCircle size={18} color="#111318" />
            {(ride?.messages || []).length > seenMsgCount && (
              <span className="absolute top-1 right-1 w-2.5 h-2.5 rounded-full" style={{ background: AMBER }} />
            )}
          </button>
        </div>
        <div className="mt-4 flex items-center gap-2 text-xs" style={{ color: "#7A7F8A" }}>
          <Clock size={13} />
          <span>{phase === "toPickup" ? "Arriving soon" : phase === "waitingPickup" ? "Waiting to start" : "En route"}</span>
        </div>
      </div>
      {chatOpen && (
        <ChatPanel rideId={rideId} mySender="rider" otherName={driverName} quickReplies={QUICK_REPLIES_RIDER} onClose={() => setChatOpen(false)} />
      )}
    </div>
  );
}

// ---------- Ride complete ----------
function CompleteScreen({ destination, driverName, driverUid, onDone }) {
  const [stars, setStars] = useState(0);
  const [submitted, setSubmitted] = useState(false);
  const [busy, setBusy] = useState(false);

  const submit = async (chosen) => {
    setStars(chosen);
    if (!driverUid) { setSubmitted(true); return; }
    setBusy(true);
    await rateDriver(driverUid, chosen);
    setBusy(false);
    setSubmitted(true);
  };

  return (
    <div className="w-full h-full flex flex-col items-center justify-center px-8" style={{ background: "#111318" }}>
      <div className="w-16 h-16 rounded-full flex items-center justify-center mb-6" style={{ background: ACCENT }}>
        <Check size={28} color="#111318" />
      </div>
      <h2 className="text-xl font-semibold" style={{ color: "#F5F5F0" }}>Ride complete</h2>
      <p className="text-sm mt-1 mb-6 text-center" style={{ color: "#7A7F8A" }}>You arrived at {destination}{driverName ? ` with ${driverName}` : ""}.</p>

      {!submitted ? (
        <>
          <p className="text-sm mb-3" style={{ color: "#F5F5F0" }}>Rate {driverName || "your driver"}</p>
          <div className="flex gap-2 mb-8">
            {[1, 2, 3, 4, 5].map((n) => (
              <button key={n} onClick={() => submit(n)} disabled={busy} className="p-1">
                <Star size={30} fill={n <= stars ? AMBER : "none"} color={AMBER} strokeWidth={1.5} />
              </button>
            ))}
          </div>
        </>
      ) : (
        <p className="text-sm mb-8" style={{ color: AMBER }}>{stars > 0 ? "Thanks for your feedback!" : "Skipped rating."}</p>
      )}

      <button onClick={onDone} className="w-full py-3.5 rounded-xl font-medium text-base" style={{ background: ACCENT, color: "#111318" }}>Done</button>
    </div>
  );
}

// ---------- Root ----------
export default function RiderApp() {
  const [user, setUser] = useState(null);
  const [screen, setScreen] = useState("home");
  const [destination, setDestination] = useState("");
  const [rideId, setRideId] = useState(null);
  const [finalDriverName, setFinalDriverName] = useState("");
  const [finalDriverUid, setFinalDriverUid] = useState("");

  const handleConfirmDestination = async (dest) => {
    setDestination(dest);
    const trip = fareFor(dest);
    const id = await createRide({
      riderName: user.name, riderUid: user.uid,
      destination: dest, fare: trip.fare, miles: trip.miles, minutes: trip.minutes,
      riderRecording: !!user.audioRecordingEnabled,
    });
    setRideId(id);
    setScreen("finding");
  };

  const handleAccepted = (ride) => { setFinalDriverName(ride.driverName || ""); setFinalDriverUid(ride.driverUid || ""); setScreen("tracking"); };
  const handleComplete = (ride) => { setFinalDriverName(ride.driverName || ""); setFinalDriverUid(ride.driverUid || ""); setScreen("complete"); };

  if (!user) {
    return (
      <div className="w-full h-screen max-w-sm mx-auto overflow-hidden sm:rounded-[2rem] sm:h-[700px] sm:my-8 relative"
        style={{ boxShadow: "0 20px 60px rgba(0,0,0,0.4)" }}>
        <AuthScreen onAuthed={(u) => { setUser(u); setScreen("home"); }} />
      </div>
    );
  }

  return (
    <div className="w-full h-screen max-w-sm mx-auto overflow-hidden sm:rounded-[2rem] sm:h-[700px] sm:my-8 relative"
      style={{ boxShadow: "0 20px 60px rgba(0,0,0,0.4)" }}>
      {screen === "home" && <HomeScreen user={user} onRequest={() => setScreen("destination")} onLogout={async () => { await signOut(); setUser(null); }} onSafety={() => setScreen("safety")} />}
      {screen === "safety" && <SafetyToolkitScreen user={user} onBack={() => setScreen("home")} onUpdateUser={setUser} />}
      {screen === "destination" && <DestinationScreen onBack={() => setScreen("home")} onConfirm={handleConfirmDestination} />}
      {screen === "finding" && <FindingDriverScreen rideId={rideId} destination={destination} onAccepted={handleAccepted} />}
      {screen === "tracking" && <TrackingScreen rideId={rideId} destination={destination} onComplete={handleComplete} />}
      {screen === "complete" && <CompleteScreen destination={destination} driverName={finalDriverName} driverUid={finalDriverUid} onDone={() => setScreen("home")} />}
    </div>
  );
}
